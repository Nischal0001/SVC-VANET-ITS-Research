import pandas as pd
from sklearn.linear_model import LinearRegression

# Load historical traffic dataset
data = pd.read_csv("svc_vanet_system/traffic_data.csv")

# Features: Number of vehicles and congestion status
X = data[['vehicle_count', 'road_blockage']]
y = data['travel_time']

# Train the regression model
model = LinearRegression()
model.fit(X, y)

# Predict travel time for new traffic conditions
new_data = [[50, 1]]  # Example: 50 vehicles, road blockage = Yes
predicted_time = model.predict(new_data)

print(f"Predicted Travel Time: {predicted_time[0]} seconds")
