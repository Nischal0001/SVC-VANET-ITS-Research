from flask import Flask, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB Connection (Database for resource tracking)
client = MongoClient("mongodb://localhost:27017/")
db = client['svc_vanet']
resources_collection = db['resources']

# Initialize cloud resources (CPU & Memory)
resources = {"CPU": 80, "Memory": 50}
resources_collection.insert_one(resources)

@app.route('/svc/request', methods=['POST'])
def allocate_resources():
    data = request.json
    required_cpu = data.get("cpu", 0)
    required_memory = data.get("memory", 0)

    # Fetch current resources
    current_resources = resources_collection.find_one()
    
    if required_cpu <= current_resources["CPU"] and required_memory <= current_resources["Memory"]:
        # Deduct resources
        new_cpu = current_resources["CPU"] - required_cpu
        new_memory = current_resources["Memory"] - required_memory
        
        # Update database
        resources_collection.update_one({}, {"$set": {"CPU": new_cpu, "Memory": new_memory}})
        
        return jsonify({"status": "Accepted", "resources": {"CPU": new_cpu, "Memory": new_memory}})
    
    return jsonify({"status": "Rejected", "message": "Insufficient resources"})

if __name__ == '__main__':
    app.run(debug=True)
