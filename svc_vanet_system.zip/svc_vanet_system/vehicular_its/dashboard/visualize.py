import matplotlib.pyplot as plt

def plot_results():
    x = [300, 400, 500, 600, 700]
    y1 = [28500, 30800, 33000, 34500, 35500]
    y2 = [29200, 31500, 33700, 36000, 37500]
    y3 = [35200, 36800, 39000, 42600, 45500]

    plt.plot(x, y1, label="CPU 120 nodes", marker='o')
    plt.plot(x, y2, label="CPU 1 node", marker='x')
    plt.plot(x, y3, label="JS Runtime", marker='^')
    plt.xlabel("VANET Nodes")
    plt.ylabel("Time (ms)")
    plt.title("Execution Time vs VANET Nodes")
    plt.legend()
    plt.grid(True)
    plt.savefig("dashboard/performance.png")
    plt.show()
