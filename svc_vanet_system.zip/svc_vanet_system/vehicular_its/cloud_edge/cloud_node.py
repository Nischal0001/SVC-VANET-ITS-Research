import ray

@ray.remote
def cloud_process(data):
    return "Processed at Cloud"
