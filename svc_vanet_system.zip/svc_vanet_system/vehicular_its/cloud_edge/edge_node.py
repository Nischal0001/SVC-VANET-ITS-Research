import ray
from cloud_edge.cloud_node import cloud_process

@ray.remote
def edge_process(data):
    if data['latency'] < 50:
        return "Processed at Edge"
    else:
        return ray.get(cloud_process.remote(data))
