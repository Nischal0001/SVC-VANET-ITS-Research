import ray
from cloud_edge.edge_node import edge_process

ray.init()
data_sample = {"latency": 42}
result = ray.get(edge_process.remote(data_sample))
print("Offloading Result:", result)
