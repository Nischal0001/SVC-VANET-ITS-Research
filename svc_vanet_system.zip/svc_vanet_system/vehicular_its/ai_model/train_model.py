import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

df = pd.read_csv("traffic_data.csv")
X = df[['speed', 'queue_len']]
y = df['congestion']
model = RandomForestClassifier()
model.fit(X, y)
joblib.dump(model, "ai_model/model.pkl")
