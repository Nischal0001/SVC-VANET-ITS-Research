import joblib

model = joblib.load("ai_model/model.pkl")

def predict(data):
    return model.predict([data])[0]
