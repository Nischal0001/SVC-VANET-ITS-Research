import traci
import os

def start_sumo():
    sumo_binary = "sumo"
    config_file = os.path.join("sumo_sim/config/ahmedabad.sumocfg")
    traci.start([sumo_binary, "-c", config_file])

def run_simulation():
    start_sumo()
    step = 0
    while step < 1000:
        traci.simulationStep()
        vehicles = traci.vehicle.getIDList()
        for veh_id in vehicles:
            speed = traci.vehicle.getSpeed(veh_id)
            pos = traci.vehicle.getPosition(veh_id)
            print(f"Vehicle {veh_id} at {pos} with speed {speed}")
        step += 1
    traci.close()

if __name__ == "__main__":
    run_simulation()
