from kafka import KafkaProducer
import json
import time

producer = KafkaProducer(bootstrap_servers='localhost:9092',
                         value_serializer=lambda v: json.dumps(v).encode('utf-8'))

while True:
    data = {"veh_id": "v1", "speed": 34.5, "latency": 45}
    producer.send("vehicle_data", data)
    time.sleep(1)
