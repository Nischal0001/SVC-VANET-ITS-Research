from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client['svc_vanet']
traffic_collection = db['traffic_data']

# Sample traffic data
traffic_entry = {
    "location": "Highway 101",
    "vehicle_count": 200,
    "congestion_level": "High",
    "timestamp": "2025-02-04 14:30:00"
}

traffic_collection.insert_one(traffic_entry)

print("Traffic data stored successfully.")
