import socket
import random
import time

UDP_IP = "127.0.0.1"
UDP_PORT = 5005

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

vehicle_id = f"V_{random.randint(100,999)}"

while True:
    position = (random.randint(0, 1000), random.randint(0, 1000))  
    speed = random.randint(10, 80)  
    congestion = random.choice(["Low", "Medium", "High"])

    message = f"{vehicle_id}, Position: {position}, Speed: {speed}, Congestion: {congestion}"
    sock.sendto(message.encode(), (UDP_IP, UDP_PORT))

    print(f"Sent: {message}")
    time.sleep(5)  
    
