import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd

# Define simulation parameters
num_nodes = 100
communication_radius = 250  # in meters
map_size = (1000, 1000)  # Width x Height

# Initialize graph
G = nx.Graph()

# Place the first node randomly
first_node = (np.random.randint(0, map_size[0]), np.random.randint(0, map_size[1]))
G.add_node(0, pos=first_node)

# Function to generate candidate nodes within bounds
def generate_candidate_node(min_x, max_x, min_y, max_y):
    x = np.random.uniform(min_x, max_x)
    y = np.random.uniform(min_y, max_y)
    return (x, y)

# Place nodes while ensuring connectivity
for i in range(1, num_nodes):
    best_candidate = None
    min_metric = float('inf')

    for _ in range(10):  # Evaluate 10 candidate nodes per iteration
        candidate = generate_candidate_node(0, map_size[0], 0, map_size[1])
        
        connected_nodes = [
            node for node in G.nodes if np.linalg.norm(np.array(candidate) - np.array(G.nodes[node]['pos'])) <= communication_radius
        ]

        if connected_nodes:
            metric = sum(np.linalg.norm(np.array(candidate) - np.array(G.nodes[node]['pos'])) for node in connected_nodes)

            if metric < min_metric:
                min_metric = metric
                best_candidate = candidate
                best_connections = connected_nodes  

    if best_candidate:
        G.add_node(i, pos=best_candidate)
        for node in best_connections:
            G.add_edge(i, node)  

# Draw the generated topology
pos = nx.get_node_attributes(G, 'pos')
nx.draw(G, pos, with_labels=True, node_size=50, edge_color="gray")
nx.draw_networkx_edges(G, pos, edge_color="blue", alpha=0.5)
plt.title("NPART-Generated Vehicular Network")
plt.show()

# Save topology to CSV
df = pd.DataFrame([(node, pos) for node, pos in pos.items()], columns=["Node", "Position"])
df.to_csv("npart_topology.csv", index=False)

print("Topology saved to npart_topology.csv")
