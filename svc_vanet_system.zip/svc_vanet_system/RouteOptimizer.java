import java.util.Scanner;

public class RouteOptimizer {
    public static double optimizeRoute(double rs, double A, double mu, double Td, double P, double Ta) {
        return (rs / (A * (1 / mu - rs))) + Td + (P * Ta);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter number of vehicles on road segment:");
        double rs = scanner.nextDouble();
        
        System.out.println("Enter vehicle arrival rate:");
        double A = scanner.nextDouble();
        
        System.out.println("Enter max capacity of road segment:");
        double mu = scanner.nextDouble();
        
        System.out.println("Enter travel delay:");
        double Td = scanner.nextDouble();
        
        System.out.println("Enter probability of traffic events:");
        double P = scanner.nextDouble();
        
        System.out.println("Enter additional delay due to congestion:");
        double Ta = scanner.nextDouble();
        
        double travelTime = optimizeRoute(rs, A, mu, Td, P, Ta);
        System.out.println("Optimized Travel Time: " + travelTime + " seconds");
        
        scanner.close();
    }
}
