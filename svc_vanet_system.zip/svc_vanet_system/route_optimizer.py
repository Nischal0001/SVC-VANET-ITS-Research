import numpy as np

def optimize_route(vehicles_on_segment, arrival_rate, max_capacity, travel_delay, probability, additional_delay):
    """Computes the optimal travel time."""
    return (vehicles_on_segment / (arrival_rate * (1 / max_capacity - vehicles_on_segment))) + travel_delay + (probability * additional_delay)

vehicles_on_segment = 50
arrival_rate = 100
max_capacity = 200
travel_delay = 5
probability = 0.2
additional_delay = 3

optimized_time = optimize_route(vehicles_on_segment, arrival_rate, max_capacity, travel_delay, probability, additional_delay)
print(f"Optimized Travel Time: {optimized_time:.2f} seconds")
