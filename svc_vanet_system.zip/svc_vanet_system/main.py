# Regenerate the traffic data with a 'travel_time' column
import pandas as pd
import random

# Generate new traffic data
data = {
    "location": [f"Location_{i}" for i in range(1, 51)],
    "vehicle_count": [random.randint(50, 200) for _ in range(50)],
    "road_blockage": [random.choice([0, 1]) for _ in range(50)],  # 0: No blockage, 1: Blockage
    "timestamp": [f"2025-02-04 14:{random.randint(10, 59):02d}:{random.randint(10, 59):02d}" for _ in range(50)],
}

# Create DataFrame
df = pd.DataFrame(data)

# Add 'travel_time' column with random values
df['travel_time'] = [random.randint(30, 150) for _ in range(len(df))]

# Save to CSV
updated_file_path = "svc_vanet_system/traffic_data.csv"
df.to_csv(updated_file_path, index=False)

updated_file_path
