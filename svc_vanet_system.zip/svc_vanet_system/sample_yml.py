import yaml

# Load the config
with open("svc_vanet_system/system_architecture.yaml", "r") as file:
    config = yaml.safe_load(file)

# Access specific parts
print("Number of vehicles:", config["vehicles"]["number_of_vehicles"])
print("Cloud services:", config["cloud_layer"]["services"])
print("Edge node compute:", config["edge_nodes"]["compute"])
