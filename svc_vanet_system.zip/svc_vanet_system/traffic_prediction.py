import pandas as pd
from sklearn.linear_model import LinearRegression

data = pd.read_csv("traffic_data.csv")

X = data[['vehicle_count', 'road_blockage']]
y = data['travel_time']

model = LinearRegression()
model.fit(X, y)

new_data = [[50, 1]]  
predicted_time = model.predict(new_data)

print(f"Predicted Travel Time: {predicted_time[0]:.2f} seconds")
